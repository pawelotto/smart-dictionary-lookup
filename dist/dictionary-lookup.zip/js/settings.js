document.addEventListener("DOMContentLoaded", function() {
  readSettings()
  var fromInput = document.getElementById("fromLang")
  var toInput = document.getElementById("toLang")
  var submitBtn = document.getElementById("save")
  submitBtn.onclick = saveSettings
})

function saveSettings() {
  var from = document.getElementById("fromLang").value
  var to = document.getElementById("toLang").value
  browser.storage.local.set({ fromLang: from })
  browser.storage.local.set({ toLang: to })
}

function readSettings(){
  browser.storage.local.get("fromLang", function(val) {
    document.getElementById("fromLang").value = val.fromLang
  })
  browser.storage.local.get("toLang", function(val) {
    document.getElementById("toLang").value = val.toLang
  })
}